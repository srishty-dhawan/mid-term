import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JeanslistComponent } from './jeanslist.component';

describe('JeanslistComponent', () => {
  let component: JeanslistComponent;
  let fixture: ComponentFixture<JeanslistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JeanslistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JeanslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
