import { Component, OnInit } from '@angular/core';
import { Content } from '../helper-files/content-interface';


@Component({
  selector: 'app-jeanslist',
  templateUrl: './jeanslist.component.html',
  styleUrls: ['./jeanslist.component.css']
})
export class JeanslistComponent implements OnInit {

  jeansList:Content[];

  filterJeansList:any;

  initialCard = true;

  searchCard = false;

  constructor() {
    this.jeansList = [{
      id: 1,
      size: 30,
      brand: "Levi",
      description: "Levi's Men's 550 Relaxed Fit Jeans",
      cutType:  "517 Straight leg",
      employeeName:  "abc",
      quantity: 20,
    },
    {
      id: 2,
      size: 30,
      brand: "Lee",
      description: "Lee Men's Performance Series Extreme Motion Straight Fit Tapered Leg Jean",
      cutType:  "417 straight fit",
      employeeName:  "abc",
      quantity: 12,
    },
    {
      id: 3,
      size: 30,
      brand: "Weatherproof Vintage",
      description: "Weatherproof Vintage Men's Slim Fit Super-Soft Stretch Denim Jeans, Five Pocket",
      cutType:  "214 slim fit",
      employeeName:  "abc",
      quantity: 15,
    },
    {
      id: 4,
      size: 30,
      brand: "ETHANOL",
      description: "ETHANOL Mens Slim Stretch Denim Five Pocket Jean",
      cutType:  "425 SLIM FIT",
      employeeName:  "abc",
      quantity: 20,
    },
    {
      id: 5,
      size: 30,
      brand: "GINGTTO",
      description: "Levi's Men's 550 Relaxed Fit Jeans",
      cutType:  "458 skinny fit",
      employeeName:  "abc",
      quantity: 12,
    },
    {
      id: 6,
      size: 30,
      brand: "Levi",
      description: "Levi's Men's 550 Relaxed Fit Jeans",
      cutType:  "517 Straight leg",
      employeeName:  "abc",
      quantity: 20,
    },
    {
      id: 7,
      size: 30,
      brand: "Lee",
      description: "Lee Men's Performance Series Extreme Motion Straight Fit Tapered Leg Jean",
      cutType:  "417 straight fit",
      employeeName:  "",
      quantity: 14,
    }
  ]
   }

  ngOnInit(): void {
  }

  displayItem(searchtext:any){
    this.initialCard = false;
    this.searchCard = true;
    console.log("search text", searchtext)
    this.filterJeansList = this.jeansList.filter(item => item.brand.toLowerCase().includes(searchtext.toLowerCase()))
    console.log("filter", this.filterJeansList)
    
  }
}
