import { QuantityhighlightDirective } from './quantityhighlight.directive';

describe('QuantityhighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new QuantityhighlightDirective();
    expect(directive).toBeTruthy();
  });
});
