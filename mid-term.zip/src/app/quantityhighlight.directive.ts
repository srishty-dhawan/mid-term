import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appQuantityhighlight]'
})
export class QuantityhighlightDirective {  

  constructor(private el: ElementRef) { }

  @HostListener('click') onMouseEnter() {
    this.highlight()
    
  } 
  
  
  private highlight() {   
    console.log(this.el.nativeElement.innerHTML)
    if(this.el.nativeElement.innerHTML >= 15){      
      this.el.nativeElement.style.color = 'green';
    }else{      
      this.el.nativeElement.style.color = 'red';
    }
  }

}
