export interface Content {   
    id: number;
    size: number;
    brand: string;
    description: string;
    cutType:  string;
    employeeName?:  string;
    quantity: number;
    }

